
//=================================================================================================

import { IStone } from "../Interfaces/IStone";
import { IPlayer } from "../Interfaces/IPlayer";

//=================================================================================================

export class Player implements IPlayer  {
    playerName: string
    points: number = 0
    playerDeck: IStone[] = [];     

    constructor(playerName: string) {
        this.playerName = playerName              
        return this;
    }
    getPlayerName():string {
        return this.playerName
    }
     setPlayerDeck(playerDeck: IStone[]) {
        this.playerDeck = playerDeck
    }
     getPlayerDeck(): IStone[] {
        return this.playerDeck
    }
     isDeckEmpty(): boolean {
        return this.playerDeck.length === 0
    }
     dropStone():IStone {          
        console.log(this.playerName + " has dropped a Stone!")              
        const playerStone = this.playerDeck.pop() 
        if(!playerStone) {// wenn stone is undefined(false)
            throw new Error('keine Steine mehr');
        }
         return playerStone     
    };
    addPoints(): number {
        this.playerDeck.forEach(IStone => {
            this.points += IStone.getStonePoints()
        })
        return this.points
    }    
}
//=================================================================================================