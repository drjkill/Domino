//=================================================================================================
//=================================================================================================
export class Player {
    constructor(playerName) {
        this.points = 0;
        this.playerDeck = [];
        this.playerName = playerName;
        return this;
    }
    getPlayerName() {
        return this.playerName;
    }
    setPlayerDeck(playerDeck) {
        this.playerDeck = playerDeck;
    }
    getPlayerDeck() {
        return this.playerDeck;
    }
    isDeckEmpty() {
        return this.playerDeck.length === 0;
    }
    dropStone() {
        console.log(this.playerName + " has dropped a Stone!");
        const playerStone = this.playerDeck.pop();
        if (!playerStone) { // wenn stone is undefined(false)
            throw new Error('keine Steine mehr');
        }
        return playerStone;
    }
    ;
    addPoints() {
        this.playerDeck.forEach(IStone => {
            this.points += IStone.getStonePoints();
        });
        return this.points;
    }
}
//=================================================================================================
