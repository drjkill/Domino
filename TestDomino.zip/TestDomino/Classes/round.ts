
//=================================================================================================

import { IPlayer } from "../Interfaces/IPlayer";
import { IStone } from "../Interfaces/IStone";
import { Player } from "./player";
import { Stone } from "./stone";

//=================================================================================================
//=================================================================================================
//                          C L A S S  G A M E
//=================================================================================================
export class Round {
    players: Array<Player> = [];
    gameArea: Array<IStone> = [];
    playerDeck: Array<IStone> = [];
    pool: Array<IStone> = [];
    winner!: IPlayer;


    constructor() {
        this.addPlayer(new Player("Donald"))
        this.addPlayer(new Player("Daisy"))

        for (let leftSide = 0; leftSide <= 4; leftSide++) {
            for (let rightSide = 0; rightSide <= 4; rightSide++) {
                const stone: IStone = new Stone(leftSide, rightSide);
                this.pool.push(stone);
            }
        }
        this.setUpDeck()
        this.setUpGameArea()
    }
    addPlayer(player: Player): Player {
        this.players.push(player)
        return player;
    }

    setUpDeck() {
        this.players.forEach(player => {
            player.setPlayerDeck(this.playerDeck)
        })
    }
    setUpGameArea() {
        this.setGameArea(this.getGameArea())
    }
    setGameArea(gameArea: IStone[]): void {
        this.gameArea = gameArea
    }
    getPlayerDeck(): IStone[] {
        const playerDeck: IStone[] = []
        for (let i = 0; i <= 4; i++) {
            const stone: number = Math.floor(Math.random() * this.pool.length);
            playerDeck.push(this.pool[stone]);
            this.pool.splice(stone, 1);
        }
        return playerDeck
    }
    getGameArea(): IStone[] {
        const gameArea: IStone[] = []
        const stone: number = Math.floor(Math.random() * this.pool.length);
        gameArea.push(this.pool[stone]);
        this.pool.splice(stone, 1);
        return gameArea
    }
}
//=================================================================================================
//                            I N I T I A L I S I E R U N G
//=================================================================================================
const round = new Round();
