//=================================================================================================
import { Player } from "./player";
import { Stone } from "./stone";
//=================================================================================================
//=================================================================================================
//                          C L A S S  G A M E
//=================================================================================================
export class Round {
    constructor() {
        this.players = [];
        this.gameArea = [];
        this.playerDeck = [];
        this.pool = [];
        this.addPlayer(new Player("Donald"));
        this.addPlayer(new Player("Daisy"));
        for (let leftSide = 0; leftSide <= 4; leftSide++) {
            for (let rightSide = 0; rightSide <= 4; rightSide++) {
                const stone = new Stone(leftSide, rightSide);
                this.pool.push(stone);
            }
        }
        this.setUpDeck();
        this.setUpGameArea();
    }
    addPlayer(player) {
        this.players.push(player);
        return player;
    }
    setUpDeck() {
        this.players.forEach(player => {
            player.setPlayerDeck(this.playerDeck);
        });
    }
    setUpGameArea() {
        this.setGameArea(this.getGameArea());
    }
    setGameArea(gameArea) {
        this.gameArea = gameArea;
    }
    getPlayerDeck() {
        const playerDeck = [];
        for (let i = 0; i <= 4; i++) {
            const stone = Math.floor(Math.random() * this.pool.length);
            playerDeck.push(this.pool[stone]);
            this.pool.splice(stone, 1);
        }
        return playerDeck;
    }
    getGameArea() {
        const gameArea = [];
        const stone = Math.floor(Math.random() * this.pool.length);
        gameArea.push(this.pool[stone]);
        this.pool.splice(stone, 1);
        return gameArea;
    }
}
//=================================================================================================
//                            I N I T I A L I S I E R U N G
//=================================================================================================
const round = new Round();
