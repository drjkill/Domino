//=================================================================================================
//=================================================================================================
export class Stone {
    constructor(leftSide, rightSide) {
        this.leftSide = leftSide;
        this.rightSide = rightSide;
    }
    getLeftSide() {
        return this.leftSide;
    }
    ;
    getRightSide() {
        return this.rightSide;
    }
    ;
    getStonePoints() {
        this.stonePoints = this.leftSide + this.rightSide;
        return this.stonePoints;
    }
    ;
}
//=================================================================================================
