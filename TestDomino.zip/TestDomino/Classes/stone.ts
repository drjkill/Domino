
//=================================================================================================

import { IStone } from "../Interfaces/IStone";

//=================================================================================================
export class Stone implements IStone {
    leftSide: number;
    rightSide: number;
    stonePoints?: number
    constructor(leftSide: number, rightSide: number) {
        this.leftSide = leftSide
        this.rightSide = rightSide
    }
    getLeftSide() { 
        return this.leftSide 
    };
    getRightSide() { 
        return this.rightSide 
    };

    getStonePoints(): number {
        this.stonePoints = this.leftSide + this.rightSide;
        return this.stonePoints
    };
}

//=================================================================================================