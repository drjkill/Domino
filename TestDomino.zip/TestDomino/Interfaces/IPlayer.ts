
import { IStone } from "./IStone"

//=================================================================================================
export interface IPlayer {
    getPlayerName: () => string
    addPoints:     () => number

    getPlayerDeck: () => IStone[]
    isDeckEmpty:   () => boolean
    dropStone:     () => IStone
}

//=================================================================================================