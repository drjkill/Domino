"use strict";
;
//=================================================================================================
//=================================================================================================
class Stone {
    //---------------------------------------------------------------------------------------------
    constructor(leftSide, rightSide) {
        this.leftSide = leftSide;
        this.rightSide = rightSide;
    }
    //---------------------------------------------------------------------------------------------
    getLeftSide() {
        return this.leftSide;
    }
    ;
    getRightSide() {
        return this.rightSide;
    }
    ;
    getStonePoints() {
        this.stonePoints = this.leftSide + this.rightSide;
        return this.stonePoints;
    }
    ;
}
//=================================================================================================
//                          C L A S S  P L A Y E R
//=================================================================================================
class Player {
    //---------------------------------------------------------------------------------------------
    constructor(playerName) {
        this.points = 0;
        this.playerDeck = [];
        this.playerName = playerName;
        return this;
    }
    //---------------------------------------------------------------------------------------------
    getPlayerName() {
        return this.playerName;
    }
    setPlayerDeck(playerDeck) {
        this.playerDeck = playerDeck;
        // @ts-ignore
        document.getElementById("output_playerDeck").innerHTML = `PlayerDeck: ${JSON.stringify(this.playerDeck)}`;
    }
    getPlayerDeck() {
        return this.playerDeck;
    }
    isDeckEmpty() {
        return this.playerDeck.length === 0;
    }
    dropStone() {
        const id = 0;
        const playerStone = this.playerDeck.splice(id, 1);
        const droppedStone = playerStone[0];
        if (!droppedStone) { // wenn stone is undefined(false)
            throw new Error('keine Steine mehr');
        }
        return droppedStone;
    }
    ;
    reciveStone() {
        const id = 0;
        const poolStone = round.pool.splice(id, 1);
        const recivedStone = poolStone[0];
        return recivedStone;
    }
    addStoneToDeck() {
        this.playerDeck.push(this.reciveStone());
        return this.playerDeck;
    }
    addPoints() {
        this.playerDeck.forEach(IStone => {
            this.points += IStone.getStonePoints();
        });
        return this.points;
    }
    sayHello() {
        $(".button").on('click', "btn_1", () => {
            console.log("H E L L O !!!");
        });
    }
}
//=================================================================================================
//                          C L A S S  R O U N D
//=================================================================================================
class Round {
    //---------------------------------------------------------------------------------------------
    constructor() {
        this.players = [];
        this.gameArea = [];
        this.playerDeck = [];
        this.pool = [];
        this.players = [];
        this.gameArea = [];
        this.playerDeck = [];
        this.pool = [];
        this.addPlayer(new Player("Donald"));
        this.addPlayer(new Player("Daisy"));
        // Pool erstellen
        for (let leftSide = 0; leftSide <= 4; leftSide++) {
            for (let rightSide = 0; rightSide <= 4; rightSide++) {
                const stone = new Stone(leftSide, rightSide);
                this.pool.push(stone);
            }
        }
        this.setPlayerDeck();
        this.setUpGameArea();
    }
    //---------------------------------------------------------------------------------------------
    addPlayer(player) {
        this.players.push(player);
        return player;
    }
    setPlayerDeck() {
        this.players.forEach(player => {
            player.setPlayerDeck(this.getPlayerDeck());
        });
    }
    setUpGameArea() {
        this.setGameArea(this.getGameArea());
    }
    setGameArea(gameArea) {
        this.gameArea = gameArea;
        // @ts-ignore
        document.getElementById("output_gameArea").innerHTML = `GameArea: ${JSON.stringify(this.gameArea)}`;
    }
    getPlayerDeck() {
        const playerDeck = [];
        for (let i = 0; i <= 4; i++) {
            const stone = Math.floor(Math.random() * this.pool.length);
            playerDeck.push(this.pool[stone]);
            this.pool.splice(stone, 1);
        }
        return playerDeck;
    }
    getGameArea() {
        const gameArea = [];
        const stone = Math.floor(Math.random() * this.pool.length);
        gameArea.push(this.pool[stone]);
        this.pool.splice(stone, 1);
        return gameArea;
    }
    hasRoundEndet() {
        for (let player of this.players) {
            if (player.isDeckEmpty()) {
                return true;
            }
        }
        ;
        return false;
    }
    play() {
        while (this.hasRoundEndet() == false) {
            this.players.forEach(player => {
            });
        }
    }
}
//=================================================================================================
//                            I N I T I A L I S I E R U N G
//=================================================================================================
const round = new Round();
//=================================================================================================
//                           O U T P U T S  I N D E X . H T M L
//=================================================================================================
// @ts-ignore
//document.getElementById("output_pool").innerHTML = `Pool: ${JSON.stringify(round.pool)}`
// @ts-ignore
//document.getElementById("output_winner").innerHTML = `Winner is: ${game.getWinner()}`
//=================================================================================================
//                         B U T T O N  E V E N T  L I S T E N E R
//=================================================================================================
/*

document.addEventListener("DOMContentLoaded", function () {

    const button1_handler = () => {                       //  stone 0 aus playerDeck
        console.table(round.players[0].playerDeck[0])

    }
    document.getElementById("btn_1")?.addEventListener("click", button1_handler);
    //----------------------------------------------------------------------------
    const button2_handler = () => {                       //  stone 1 aus playerDeck
        console.table(round.players[0].playerDeck[1])
    }
    document.getElementById("btn_2")?.addEventListener("click", button2_handler);
    //----------------------------------------------------------------------------
    const button3_handler = () => {                       //  stone 2 aus playerDeck
        console.table(round.players[0].playerDeck[2])
    }
    document.getElementById("btn_3")?.addEventListener("click", button3_handler);
    //----------------------------------------------------------------------------
    const button4_handler = () => {                       //  stone 3 aus playerDeck
        console.table(round.players[0].playerDeck[3])
    }
    document.getElementById("btn_4")?.addEventListener("click", button4_handler);
    //----------------------------------------------------------------------------
    const button5_handler = () => {                       //  stone 4 aus playerDeck
        console.table(round.players[0].playerDeck[4])
    }
    document.getElementById("btn_5")?.addEventListener("click", button5_handler);
    //----------------------------------------------------------------------------
    const button6_handler = () => {                       // ziehe Stone aus Pool
        console.table(round.players[0].addStoneToDeck())
    }
    document.getElementById("btn_6")?.addEventListener("click", button6_handler);
});
*/ 
